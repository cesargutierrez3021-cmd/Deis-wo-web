import { useMemo, useState } from 'react'
import { Activity, CircleDot, Plus, Trophy, Waves } from 'lucide-react'
import { Pantalla, TituloPantalla } from '../../components/shell/Pantalla'
import { Boton, Card, Campo, Chip, Entrada, EntradaPesos, TituloSeccion } from '../../components/ui/primitives'
import { useTienda } from '../../lib/store'
import { MERCADOS_APUESTA, type Apuesta, type MercadoApuesta } from '../../lib/types'

const LINEAS = [0.5, 1.5, 2.5, 3.5, 4.5]
function dinero(n: number) { return `$${Math.round(n).toLocaleString('es-CO')}` }
function beneficio(a: Apuesta) { return a.resultado === 'ganada' ? a.stake * (a.cuota - 1) : a.resultado === 'perdida' ? -a.stake : 0 }
function pct(n: number) { return `${n.toFixed(1)}%` }

export function TipstersScreen() {
  const tipsters = useTienda((s) => s.tipsters)
  const apuestas = useTienda((s) => s.apuestas)
  const capital = useTienda((s) => s.ajustes.capitalTipsters ?? 100000)
  const agregar = useTienda((s) => s.agregarApuesta)
  const agregarTipster = useTienda((s) => s.agregarTipster)
  const actualizarResultado = useTienda((s) => s.actualizarResultadoApuesta)
  const actualizarAjustes = useTienda((s) => s.actualizarAjustes)
  const [tipsterId, setTipsterId] = useState(tipsters[0]?.id ?? 'cesar')
  const [partido, setPartido] = useState('')
  const [mercado, setMercado] = useState<MercadoApuesta>('Gana')
  const [linea, setLinea] = useState('')
  const [mercado2, setMercado2] = useState<MercadoApuesta | ''>('')
  const [cuotaTexto, setCuotaTexto] = useState('1.5')
  const [stakeTexto, setStakeTexto] = useState('1')
  const [nuevoTipster, setNuevoTipster] = useState('')
  const estadisticas = useMemo(() => tipsters.map((t) => {
    const aps = apuestas.filter((a) => a.tipsterId === t.id)
    const cerradas = aps.filter((a) => a.resultado !== 'pendiente')
    const apostado = cerradas.reduce((s, a) => s + a.stake, 0)
    const ganancia = cerradas.reduce((s, a) => s + beneficio(a), 0)
    const ganadas = cerradas.filter((a) => a.resultado === 'ganada').length
    const perdidas = cerradas.filter((a) => a.resultado === 'perdida').length
    const anuladas = cerradas.filter((a) => a.resultado === 'empatada' || a.resultado === 'anulada').length
    const cuotas = aps.length ? aps.reduce((s, a) => s + a.cuota, 0) / aps.length : 0
    return { ...t, apuestas: aps.length, ganadas, perdidas, anuladas, apostado, ganancia, roi: apostado ? ganancia / apostado * 100 : 0, acierto: cerradas.length ? ganadas / cerradas.length * 100 : 0, cuotaPromedio: cuotas }
  }), [apuestas, tipsters])
  function guardar() {
    const stake = Number(stakeTexto)
    const cuota = Number(cuotaTexto.replace(',', '.'))
    if (!partido || !Number.isFinite(cuota) || cuota <= 1 || stake < 1 || stake > 10) return
    agregar({ tipsterId, partido, mercados: [{ mercado, ...(linea ? { linea: Number(linea) } : {}) }, ...(mercado2 ? [{ mercado: mercado2 }] : [])], cuota, stake, confianza: stake, resultado: 'pendiente', fechaISO: new Date().toISOString() })
    setPartido(''); setLinea(''); setMercado2(''); setCuotaTexto('1.5'); setStakeTexto('1')
  }
  const maxGanancia = Math.max(1, ...estadisticas.map((s) => Math.abs(s.ganancia)))
  const maxCuota = Math.max(1, ...estadisticas.map((s) => s.cuotaPromedio))
  return <Pantalla>
    <TituloPantalla kicker="Tipsters" titulo="Pronósticos deportivos" bajada="Capital, unidades y comparación visual de tus apostadores." />
    <TituloSeccion>Capital base</TituloSeccion>
    <Card className="flex items-center justify-between gap-3 p-4"><div><p className="text-[11px] text-mute">1 unidad = 1 %</p><p className="text-[20px] font-semibold text-fg">{dinero(capital)}</p></div><EntradaPesos valor={capital} onCambio={(v) => actualizarAjustes({ capitalTipsters: v })} /></Card>
    <TituloSeccion>Agregar apuesta</TituloSeccion>
    <Card className="space-y-3 p-4">
      <div className="flex flex-wrap gap-2">{tipsters.map((t) => <Chip key={t.id} activo={tipsterId === t.id} onClick={() => setTipsterId(t.id)}>{t.nombre}</Chip>)}</div>
      <div className="flex gap-2"><Entrada value={nuevoTipster} onChange={(e) => setNuevoTipster(e.target.value)} placeholder="Nuevo apostador" /><button type="button" className="grid size-11 shrink-0 place-items-center rounded-[var(--radius-btn)] border border-line text-acento-alto" onClick={() => { if (nuevoTipster.trim()) { agregarTipster(nuevoTipster.trim()); setNuevoTipster('') } }}><Plus size={17} /></button></div>
      <Campo etiqueta="Partido"><Entrada value={partido} onChange={(e) => setPartido(e.target.value)} placeholder="Ej. Nacional vs Millonarios" /></Campo>
      <Campo etiqueta="Mercado principal"><select value={mercado} onChange={(e) => setMercado(e.target.value as MercadoApuesta)} className="min-h-11 w-full rounded-[var(--radius-btn)] border border-line bg-surface-2 px-3 text-[14px] text-fg">{MERCADOS_APUESTA.map((m) => <option key={m}>{m}</option>)}</select></Campo>
      {(mercado.includes('goles') || mercado.includes('tarjetas') || mercado.includes('córners')) && <Campo etiqueta="Línea"><select value={linea} onChange={(e) => setLinea(e.target.value)} className="min-h-11 w-full rounded-[var(--radius-btn)] border border-line bg-surface-2 px-3 text-[14px] text-fg"><option value="">Seleccionar línea</option>{LINEAS.map((l) => <option key={l}>{l}</option>)}</select></Campo>}
      <Campo etiqueta="Segunda opción (combinada, opcional)"><select value={mercado2} onChange={(e) => setMercado2(e.target.value as MercadoApuesta | '')} className="min-h-11 w-full rounded-[var(--radius-btn)] border border-line bg-surface-2 px-3 text-[14px] text-fg"><option value="">Sin combinada</option>{MERCADOS_APUESTA.map((m) => <option key={m}>{m}</option>)}</select></Campo>
      <div className="grid grid-cols-2 gap-2"><Campo etiqueta="Cuota"><Entrada inputMode="decimal" type="text" value={cuotaTexto} onChange={(e) => setCuotaTexto(e.target.value)} placeholder="Ej. 1,85" /></Campo><Campo etiqueta="Stake 1–10 (% capital)"><Entrada inputMode="numeric" type="text" value={stakeTexto} onChange={(e) => setStakeTexto(e.target.value)} placeholder="1" /></Campo></div>
      <p className="text-[11px] text-mute">Valor de esta apuesta: {dinero(capital * (Number(stakeTexto) || 0) / 100)}</p>
      <Boton disabled={!partido || !Number.isFinite(Number(cuotaTexto.replace(',', '.'))) || Number(cuotaTexto.replace(',', '.')) <= 1 || Number(stakeTexto) < 1 || Number(stakeTexto) > 10} onClick={guardar}>Guardar apuesta</Boton>
    </Card>
    <TituloSeccion>Estadística por tipster</TituloSeccion>
    <div className="space-y-2">{estadisticas.map((s) => <Card key={s.id} className="p-3.5"><div className="flex items-center justify-between"><p className="font-semibold text-fg">{s.nombre}</p><p className={`font-semibold ${s.ganancia >= 0 ? 'text-win' : 'text-loss'}`}>{s.roi.toFixed(1)} % ROI</p></div><div className="mt-3 grid grid-cols-4 gap-1 text-center text-[10px]"><div><b className="block text-fg">{s.apuestas}</b><span className="text-mute">hechas</span></div><div><b className="block text-win">{s.ganadas}</b><span className="text-mute">acertadas</span></div><div><b className="block text-loss">{s.perdidas}</b><span className="text-mute">perdidas</span></div><div><b className="block text-fg">{s.anuladas}</b><span className="text-mute">anuladas</span></div></div><div className="mt-3 flex justify-between border-t border-line pt-2 text-[11px] text-mute"><span>Unidades: <b className="text-fg">{s.ganancia.toFixed(2)} u</b></span><span>{dinero(s.ganancia * capital / 100)}</span></div></Card>)}</div>
    <TituloSeccion>Comparador visual</TituloSeccion>
    <Card className="space-y-6 p-4">
      <div><p className="mb-2 flex items-center gap-2 text-[12px] font-semibold text-fg"><Activity size={15} /> Rendimiento acumulado</p><div className="flex h-36 items-end justify-around gap-3 border-b border-line px-2">{estadisticas.map((s) => <div key={s.id} className="flex h-full flex-1 flex-col items-center justify-end gap-1"><span className="text-[9px] text-mute">{s.ganancia.toFixed(1)} u</span><div style={{ height: `${Math.max(4, Math.abs(s.ganancia) / maxGanancia * 100)}%` }} className={`w-8 rounded-t-md transition-all duration-1000 ${s.ganancia >= 0 ? 'bg-win' : 'bg-loss'}`} /><span className="max-w-full truncate text-[9px] text-mute">{s.nombre}</span></div>)}</div></div>
      <div><p className="mb-2 flex items-center gap-2 text-[12px] font-semibold text-fg"><CircleDot size={15} /> Resultados y acierto</p><div className="space-y-3">{estadisticas.map((s) => { const total = Math.max(1, s.ganadas + s.perdidas + s.anuladas); return <div key={s.id}><div className="mb-1 flex justify-between text-[10px] text-mute"><span>{s.nombre} · {pct(s.acierto)}</span><span>{s.ganadas} acertadas · {s.perdidas} perdidas · {s.anuladas} anuladas</span></div><div className="flex h-5 overflow-hidden rounded-full bg-surface-3"><div style={{ width: `${s.ganadas / total * 100}%` }} className="bg-win transition-all duration-1000" /><div style={{ width: `${s.perdidas / total * 100}%` }} className="bg-loss transition-all duration-1000" /><div style={{ width: `${s.anuladas / total * 100}%` }} className="bg-acento transition-all duration-1000" /></div></div> })}</div></div>
      <div><p className="mb-2 flex items-center gap-2 text-[12px] font-semibold text-fg"><Waves size={15} /> Cuota promedio</p><svg viewBox="0 0 300 115" className="h-28 w-full overflow-visible">{estadisticas.map((s, i) => { const x = 30 + i * (240 / Math.max(1, estadisticas.length - 1)); const y = 90 - (s.cuotaPromedio / maxCuota) * 65; const previo = estadisticas[i - 1]; const px = previo ? 30 + (i - 1) * (240 / Math.max(1, estadisticas.length - 1)) : x; const py = previo ? 90 - (previo.cuotaPromedio / maxCuota) * 65 : y; return <g key={s.id}><line x1={px} y1={py} x2={x} y2={y} stroke="var(--c-acento)" strokeWidth="3" className="transition-all duration-1000" /><circle cx={x} cy={y} r="7" fill="var(--c-surface)" stroke="var(--c-acento)" strokeWidth="3" className="animate-pulse" /><text x={x} y="108" textAnchor="middle" className="fill-mute text-[9px]">{s.nombre}</text><text x={x} y={y - 10} textAnchor="middle" className="fill-fg text-[9px]">{s.cuotaPromedio.toFixed(2)}</text></g> })}</svg></div>
    </Card>
    <TituloSeccion><span className="flex items-center gap-2"><Trophy size={15} /> Ranking</span></TituloSeccion><Card className="p-0">{[...estadisticas].sort((a, b) => b.ganancia - a.ganancia).map((s, i) => <div key={s.id} className="flex items-center justify-between border-b border-line px-4 py-3 last:border-0"><span className="text-[13px] text-fg">#{i + 1} · {s.nombre}</span><b className={s.ganancia >= 0 ? 'text-win' : 'text-loss'}>{dinero(s.ganancia * capital / 100)}</b></div>)}</Card>
    <TituloSeccion>Apuestas recientes</TituloSeccion><div className="space-y-2">{apuestas.slice(0, 20).map((a) => <Card key={a.id} className="p-3"><div className="flex justify-between gap-2"><div><b className="text-[13px] text-fg">{a.partido}</b><p className="text-[10px] text-mute">{tipsters.find((t) => t.id === a.tipsterId)?.nombre ?? 'Sin tipster'} · {a.mercados.map((m) => `${m.mercado}${m.linea ? ` ${m.linea}` : ''}`).join(' + ')}</p></div><b className="text-acento-alto">{a.cuota.toFixed(2)}</b></div><div className="mt-2 flex items-center gap-1.5">{(['pendiente', 'ganada', 'perdida', 'anulada'] as const).map((r) => <button type="button" key={r} onClick={() => actualizarResultado(a.id, r)} className={`rounded-full border px-2 py-1 text-[9px] capitalize ${a.resultado === r ? 'border-acento-linea text-acento-alto' : 'border-line text-mute'}`}>{r}</button>)}</div></Card>)}</div>
  </Pantalla>
}
